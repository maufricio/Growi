using GrowiApp_PED.Entities;
using GrowiApp_PED.Models;
using System.Data.SqlClient;
namespace GrowiApp_PED
{
    public partial class Form1 : Form
    {
        DatabaseConnection dbConn;
        SqlConnection connStored;

        List<UsuarioEntity> usuarios = new List<UsuarioEntity>();
        public Form1()
        {
            InitializeComponent();

            DisplayData();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
        }

        public void DisplayData()
        {
            //El parametro que se pasa es el nombre de la variable en la que reunimos los valores
            //de las propiedades del usuario, el cual es UserToString
            listBox1.DataSource = usuarios;
            listBox1.DisplayMember = "UserToString";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            UserDataAccess userDb = new UserDataAccess();
            this.usuarios = userDb.getUsuarios();

            DisplayData();

        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}