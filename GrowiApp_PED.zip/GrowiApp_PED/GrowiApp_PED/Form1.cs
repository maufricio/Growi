using GrowiApp_PED.Entities;
using GrowiApp_PED.Models;
using System.Data.SqlClient;
namespace GrowiApp_PED
{
    public partial class Form1 : Form
    {
        DatabaseConnection dbConn;
        SqlConnection connStored;

        List<UsuarioEntity> usuarios = new List<UsuarioEntity>();
        public Form1()
        {
            InitializeComponent();
            listBox1.DataSource = usuarios;
            listBox1.DisplayMember = "UserToString";
        }

        private void Form1_Load(object sender, EventArgs e)
        {
        }

        private void button1_Click(object sender, EventArgs e)
        {
            UserDataAccess userDb = new UserDataAccess();
            this.usuarios = userDb.getUsuarios();


        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}