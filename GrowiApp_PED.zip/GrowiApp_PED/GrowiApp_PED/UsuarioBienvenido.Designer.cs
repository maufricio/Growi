﻿namespace GrowiApp_PED
{
    partial class UsuarioBienvenido
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.imagenCarga = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.imagenCarga)).BeginInit();
            this.SuspendLayout();
            // 
            // imagenCarga
            // 
            this.imagenCarga.Location = new System.Drawing.Point(12, 24);
            this.imagenCarga.Name = "imagenCarga";
            this.imagenCarga.Size = new System.Drawing.Size(776, 394);
            this.imagenCarga.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.imagenCarga.TabIndex = 0;
            this.imagenCarga.TabStop = false;
            this.imagenCarga.Click += new System.EventHandler(this.imagenCarga_Click);
            // 
            // UsuarioBienvenido
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Cyan;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.ControlBox = false;
            this.Controls.Add(this.imagenCarga);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "UsuarioBienvenido";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "UsuarioBienvenido";
            this.Load += new System.EventHandler(this.UsuarioBienvenido_Load);
            ((System.ComponentModel.ISupportInitialize)(this.imagenCarga)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private PictureBox imagenCarga;
    }
}