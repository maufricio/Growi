﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GrowiApp_PED
{
    public partial class UsuarioBienvenido : Form
    {
        Form1 form1;
        public UsuarioBienvenido()
        {
            InitializeComponent();
        }

        private void imagenCarga_Click(object sender, EventArgs e)
        {
        }

        private async void UsuarioBienvenido_Load(object sender, EventArgs e)
        {
            this.imagenCarga.Load("loadImageScreen.gif");
            this.imagenCarga.Location = new Point(this.Width / 2 - this.imagenCarga.Width / 2, this.Height / 2 - this.imagenCarga.Height /2 );
            
            //Comienza la tarea asignada, en este caso tiene que esperar 4 segundos
            Task oTask = new Task(Espera);
            oTask.Start();

            await oTask;
            this.Hide();

            form1 = new Form1();
            form1.Show();
        }
        public void Espera()
        {
            Thread.Sleep(4000);
        }
    }
}
