﻿using GrowiApp_PED.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Dapper;
using System.Data;

namespace GrowiApp_PED.Models
{
    public class UserDataAccess
    {
        public List<UsuarioEntity> getUsuarios()
        {
            //Using nos va a servir para trabajar cosas actuales, de tal manera que 
            //cuando se salga de los brackets, se terminará el proceso
            using(IDbConnection connection = new System.Data.SqlClient.SqlConnection(HelperDb.CnnVal("GrowiAppDB")))
            {
                if (connection != null)
                    MessageBox.Show("Conexion establecida");
                return connection.Query<UsuarioEntity>($"SELECT * FROM usuarios").ToList();
            }

            //throw new NotImplementedException(); //nos permite compilar la aplicacion
        }

        public int insertUsuario(UsuarioEntity usuario)
        {
            using(IDbConnection connection = new System.Data.SqlClient.SqlConnection(HelperDb.CnnVal("GrowiAppDB")))
            {
                if (connection != null)
                    MessageBox.Show("Conexion establecida");

                string sql = "INSERT INTO usuarios ()";
                return 1;
            }
        }
    }
}
