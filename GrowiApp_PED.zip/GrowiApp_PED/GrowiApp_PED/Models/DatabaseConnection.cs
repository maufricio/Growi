﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace GrowiApp_PED.Models
{
    public class DatabaseConnection
    {

        private string server_name;
        private string user_name;
        private string password;
        private string database_name;
        

        public DatabaseConnection() 
        {
            this.server_name = "localhost";
            this.user_name = "sa";
            this.password = null;
            this.database_name = "GrowitApp";
        }

        public SqlConnection getConnection()
        {
            string connectionString = "Data Source=tcp:"+this.server_name+";Initial Catalog=" + this.database_name + "Integrated Security=True;";
            SqlConnection cnn = new SqlConnection(connectionString);
            cnn.Open();
            MessageBox.Show("Conexión entablada con la base de datos Growi.");
            return cnn;
        }

        public void killConnection(SqlConnection sqlConnection)
        {
            sqlConnection.Close();
        }



    }
}
