﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GrowiApp_PED.Entities
{
    public class UsuarioEntity
    {
        private int Id_usuario { get; set;}
        private string NombreUsuario { get; set; }
        private string Telefono { get; set; }
        private string Email { get; set; }
        private int Autenticacion { get; set; }


        //Convierte todas las propiedades en un solo resultado
        public string UserToString
        {
            get 
            {
                return $"{Id_usuario} {NombreUsuario} {Telefono} ({Email}) Autentificado: {Autenticacion}";
            }
        }

    }
}
